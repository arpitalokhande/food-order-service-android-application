package com.example.lenovo.letseat;

import android.content.ClipData;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

public class welcome extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

private DrawerLayout drawer;

    private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
     //   Button cart1;
    private ClipData.Item cart1;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_welcome);
            setTitle("Categories");
            android.support.v7.widget.Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);
            drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.navigation);
            navigationView.setNavigationItemSelectedListener(this);

            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();


                        button1 = (Button) findViewById(R.id.button1);
                        button1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                openBreakfast();
                            }
                        });
                        button2 = (Button) findViewById(R.id.button2);
                        button2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                openlunch();
                            }
                        });
            button4= (Button) findViewById(R.id.button4);
            button4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openchat();
                }


            });

                button3= (Button) findViewById(R.id.button3);
                button3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                openchinese();
                        }




                });

                button5= (Button) findViewById(R.id.button5);
                button5.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                openbeverages();
                        }


                });



                    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        Intent i;
        switch (item.getItemId())
        {
            case R.id.cartview:
                i= new Intent(this,Cart.class);
                startActivity(i);
                break;
            case R.id.logout:
                i=new Intent(this,signin.class);
                startActivity(i);
                finish();
                break;
            case R.id.myorders:
                i=new Intent(this,myorders.class);
                startActivity(i);
                break;
        }
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    public void openBreakfast()
        {
                Intent intent=new Intent(this,Breakfast.class);
                startActivity(intent);
        }
        public void openlunch()
        {
                Intent intent=new Intent(this,lunch.class);
                startActivity(intent);
        }
       public void openchat()
      {
        Intent intent=new Intent(this,chat.class);
        startActivity(intent);
      }

        public void openchinese()
        {
                Intent intent=new Intent(this,chinese.class);
                startActivity(intent);
        }
        public void openbeverages()
        {
                Intent intent=new Intent(this,beverages.class);
                startActivity(intent);
        }

}
