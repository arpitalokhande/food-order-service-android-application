package com.example.lenovo.letseat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.lenovo.letseat.Database.Database;
import com.example.lenovo.letseat.model.Order;

public class chat extends AppCompatActivity {
   Float price;
   String foodID="";
   int id;

    private Button  panipuri;
    private  Button dahipuri;
    private  Button ragadapattice;
    private  Button olibhel;
    private Button shevpaav;
    private Button dabeli;

    ElegantNumberButton counterButton18;
    ElegantNumberButton counterButton19;
    ElegantNumberButton counterButton20;
    ElegantNumberButton counterButton21;
    ElegantNumberButton counterButton22;
    ElegantNumberButton counterButton23;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        setTitle("Chat");

        counterButton18= (ElegantNumberButton)findViewById(R.id.number_button18);
        counterButton19= (ElegantNumberButton)findViewById(R.id.number_button19);
        counterButton20= (ElegantNumberButton)findViewById(R.id.number_button20);
        counterButton21= (ElegantNumberButton)findViewById(R.id.number_button21);
        counterButton22= (ElegantNumberButton)findViewById(R.id.number_button22);
        counterButton23= (ElegantNumberButton)findViewById(R.id.number_button23);

        panipuri = (Button) findViewById(R.id.panipuri);
        panipuri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "18",
                        "Pani Puri",
                        counterButton18.getNumber(),
                        "20"
                ));

                Toast.makeText(chat.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        dahipuri = (Button) findViewById(R.id.dahipuri);
        dahipuri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "19",
                        "Dahi Puri",
                        counterButton19.getNumber(),
                        "25"
                ));

                Toast.makeText(chat.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        ragadapattice = (Button) findViewById(R.id.ragdapattice);
       ragadapattice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "20",
                        "Ragada Pattice",
                        counterButton20.getNumber(),
                        "25"
                ));

                Toast.makeText(chat.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        olibhel = (Button) findViewById(R.id.olibhel);
        olibhel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "21",
                        "Oli Bhel",
                        counterButton21.getNumber(),
                        "25"
                ));

                Toast.makeText(chat.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        shevpaav = (Button) findViewById(R.id.shevpaav);
       shevpaav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "22",
                        "Shev Pav",
                        counterButton22.getNumber(),
                        "20"
                ));

                Toast.makeText(chat.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        dabeli = (Button) findViewById(R.id.dabeli);
        dabeli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "23",
                        "Dabli",
                        counterButton23.getNumber(),
                        "10"
                ));

                Toast.makeText(chat.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
