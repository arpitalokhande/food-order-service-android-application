package com.example.lenovo.letseat;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.letseat.Common.Common;
import com.example.lenovo.letseat.model.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.rengwuxian.materialedittext.MaterialEditText;

public class signin extends AppCompatActivity {
  EditText edtphone,edtpassword;
  Button btnsignin;

    private TextView textView;
    private GestureDetectorCompat gestureObject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin);
        setTitle("Sign In");

     /*btnsignin= (Button) findViewById(R.id.btnsignin);
       btnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openwelcome();
            }*/
        edtpassword=(MaterialEditText)findViewById(R.id.edtpassword);
        edtphone=(MaterialEditText)findViewById(R.id.edtphone);
        btnsignin= (Button)findViewById(R.id.btnsignin);
        final FirebaseDatabase database=FirebaseDatabase.getInstance();
        final DatabaseReference table_user= database.getReference("User");

        btnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final  ProgressDialog mDialog = new ProgressDialog(signin.this);
                mDialog.setMessage("Please wait");
                mDialog.show();

                table_user.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //check if user not exist in database
                        if(dataSnapshot.child(edtphone.getText().toString()).exists())
                        {
                            //get user information
                            mDialog.dismiss();
                            User user = dataSnapshot.child(edtphone.getText().toString()).getValue(User.class);
                            user.setPhone(edtphone.getText().toString());
                            if(user.getPassword().equals(edtpassword.getText().toString()))
                            {
                                Toast.makeText(signin.this,"Sign in successfully",Toast.LENGTH_SHORT).show();
                                Intent welcomeintent=new Intent(signin.this,welcome.class);
                                Common.currentuser=user;
                                startActivity(welcomeintent);
                            }
                            else
                            {
                                Toast.makeText(signin.this,"Sign in failed!!",Toast.LENGTH_SHORT).show();

                            }
                        }
                        else
                        {
                            mDialog.dismiss();
                            Toast.makeText(signin.this,"User not exist in Database!",Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        //
                    }
                });
            }
        });

        gestureObject =new GestureDetectorCompat(this,new signin.LearnGesture());
        textView=(TextView) findViewById(R.id.textView);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                opensignup();
            }
        });
    }
    @Override
    public boolean onTouchEvent(MotionEvent event)
    {

        this.gestureObject.onTouchEvent(event);
        return super.onTouchEvent(event);
    }
    class LearnGesture extends GestureDetector.SimpleOnGestureListener{

        @Override
        public boolean onFling(MotionEvent event1,MotionEvent event2,float velocityX,float velocityY){

            if(event2.getX()< event1.getX()|| event2.getX()> event1.getX()|| event2.getX()==event1.getX()){


                //  Intent intent=new Intent(signin.this,welcome.class);

                //  startActivity(intent);


            }


            return true;

        }
    }
    public void opensignup()
    {
        Intent intent=new Intent(this,signup.class);
        startActivity(intent);
    }
    public void openwelcome()
    {
        Intent intent=new Intent(this,welcome.class);
        startActivity(intent);//he
    }
}

        //he bgh te password taklyavr login sathi ahe..yesss


        //init firebase
