package com.example.lenovo.letseat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.lenovo.letseat.Database.Database;
import com.example.lenovo.letseat.model.Order;

public class chinese extends AppCompatActivity {
   String foodID="";
   int id;
    Float price;
    private Button hakkanoodles;
    private Button friedrice;
    private Button manchowsoup;
    private Button vegmachu;
    private Button schzwannoodles;
    private Button schzwanrice;
    private Button chickenroll;
    private Button paneerroll;



    ElegantNumberButton counterButton10;
    ElegantNumberButton counterButton11;
    ElegantNumberButton counterButton12;
    ElegantNumberButton counterButton13;
    ElegantNumberButton counterButton14;
    ElegantNumberButton counterButton15;
    ElegantNumberButton counterButton16;
    ElegantNumberButton counterButton17;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chinese);
        setTitle("Chinese & Rolls");

        counterButton10= (ElegantNumberButton)findViewById(R.id.number_button10);
        counterButton11= (ElegantNumberButton)findViewById(R.id.number_button11);
        counterButton12= (ElegantNumberButton)findViewById(R.id.number_button12);
        counterButton13= (ElegantNumberButton)findViewById(R.id.number_button13);
        counterButton14= (ElegantNumberButton)findViewById(R.id.number_button14);
        counterButton15= (ElegantNumberButton)findViewById(R.id.number_button15);
        counterButton16= (ElegantNumberButton)findViewById(R.id.number_button16);
        counterButton17= (ElegantNumberButton)findViewById(R.id.number_button17);

        hakkanoodles = (Button) findViewById(R.id.hakkanoodles);
        hakkanoodles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "10",
                        "Hakka Noodles",
                        counterButton10.getNumber(),
                        "50"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        friedrice = (Button) findViewById(R.id.friedrice);
       friedrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "11",
                        "Fried Rice",
                        counterButton11.getNumber(),
                        "50"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        schzwanrice = (Button) findViewById(R.id.schezwanrice);
        schzwanrice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "12",
                        "Schezwan Rice",
                        counterButton12.getNumber(),
                        "55"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        manchowsoup = (Button) findViewById(R.id.manchowsoup);
        manchowsoup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "13",
                        "Manchow Soup",
                        counterButton13.getNumber(),
                        "40"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        vegmachu = (Button) findViewById(R.id.vegmachu);
        vegmachu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "14",
                        "Veg Manchurian",
                        counterButton14.getNumber(),
                        "60"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        schzwannoodles = (Button) findViewById(R.id.schezwannoodles);
     schzwannoodles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "15",
                        "Schezwan Noodles",
                        counterButton15.getNumber(),
                        "55"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        chickenroll = (Button) findViewById(R.id.chickenroll);
        chickenroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "16",
                        "Chicken Roll",
                        counterButton16.getNumber(),
                        "60"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        paneerroll = (Button) findViewById(R.id.paneerroll);
        paneerroll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "17",
                        "Paneer Roll",
                        counterButton17.getNumber(),
                        "45"
                ));

                Toast.makeText(chinese.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
