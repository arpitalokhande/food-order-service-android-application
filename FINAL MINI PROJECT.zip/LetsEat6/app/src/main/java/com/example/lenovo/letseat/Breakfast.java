package com.example.lenovo.letseat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.lenovo.letseat.Database.Database;
import com.example.lenovo.letseat.model.Order;

public class Breakfast extends AppCompatActivity {
   //obj
    Float price=0.0f;
    String foodID="";
    int id;
    private Button kandepohe;
    private Button idli;
    private Button vadapav;
    private Button khichadi;
    private Button misal;
    private Button masaladosa;


    ElegantNumberButton counterButton1;
    ElegantNumberButton counterButton2;
    ElegantNumberButton counterButton3;
    ElegantNumberButton counterButton4;
    ElegantNumberButton counterButton5;
    ElegantNumberButton counterButton6;
    public Breakfast() {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breakfast);
        setTitle("Breakfast");

        counterButton1= (ElegantNumberButton)findViewById(R.id.number_button1);
        counterButton2= (ElegantNumberButton)findViewById(R.id.number_button2);
        counterButton3= (ElegantNumberButton)findViewById(R.id.number_button3);
        counterButton4= (ElegantNumberButton)findViewById(R.id.number_button4);
        counterButton5= (ElegantNumberButton)findViewById(R.id.number_button5);
        counterButton6= (ElegantNumberButton)findViewById(R.id.number_button6);

        kandepohe = (Button) findViewById(R.id.kandepohe);
        kandepohe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "01",
                        "Kande Pohe",
                        counterButton1.getNumber(),
                        "12"
                ));

                Toast.makeText(Breakfast.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        khichadi= (Button) findViewById(R.id.khichadi);
        khichadi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "02",
                        "Khichadi",
                        counterButton2.getNumber(),
                        "20"
                ));

                Toast.makeText(Breakfast.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        vadapav = (Button) findViewById(R.id.vadapav);
        vadapav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "03",
                        "Vada Pav",
                        counterButton3.getNumber(),
                        "12"
                ));

                Toast.makeText(Breakfast.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        misal = (Button) findViewById(R.id.misal);
       misal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "04",
                        "Misal",
                        counterButton4.getNumber(),
                        "35"
                ));

                Toast.makeText(Breakfast.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        masaladosa= (Button) findViewById(R.id.masaladosa);
       masaladosa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "05",
                        "Masala Dosa",
                        counterButton5.getNumber(),
                        "40"
                ));

                Toast.makeText(Breakfast.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        idli= (Button) findViewById(R.id.idli);
       idli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "06",
                        "Idli",
                        counterButton6.getNumber(),
                        "25"
                ));

                Toast.makeText(Breakfast.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });


    }
}