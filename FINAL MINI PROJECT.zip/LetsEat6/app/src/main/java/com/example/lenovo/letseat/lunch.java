package com.example.lenovo.letseat;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.lenovo.letseat.R;
import com.example.lenovo.letseat.Database.Database;
import com.example.lenovo.letseat.model.Order;

public class lunch extends AppCompatActivity {
    String foodID="";
    int id;
    Float price;
    private Button bhajipoli;
    private Button vegthaali;
    private Button nonvegthaali;

    ElegantNumberButton counterButton7;
    ElegantNumberButton counterButton8;
    ElegantNumberButton counterButton9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lunch);
        setTitle("Lunch");

        counterButton7= (ElegantNumberButton)findViewById(R.id.number_button7);
        counterButton8= (ElegantNumberButton)findViewById(R.id.number_button8);
        counterButton9= (ElegantNumberButton)findViewById(R.id.number_button9);

        bhajipoli = (Button) findViewById(R.id.bhajipoli);
        bhajipoli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "07",
                        "Bhaji Poli",
                        counterButton7.getNumber(),
                        "30"
                ));

                Toast.makeText(lunch.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
        vegthaali = (Button) findViewById(R.id.vegthaali);
        vegthaali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "08",
                        "Veg Thali",
                        counterButton8.getNumber(),
                        "50"
                ));

                Toast.makeText(lunch.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });

        nonvegthaali = (Button) findViewById(R.id.nonvegthaali);
        nonvegthaali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Database(getBaseContext()).addToCart(new Order(
                        "09",
                        "Non-Veg Thaali",
                        counterButton9.getNumber(),
                        "70"
                ));

                Toast.makeText(lunch.this, "Item is Added", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
